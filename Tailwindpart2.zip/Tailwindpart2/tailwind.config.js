/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,js}' ],
  theme: {
    extend: {
      colors:{
        danger: '#FFB3CF',
        info: {
          100:'#83CBEF',
          200:'#89CF55',
        },
      },
    },
  },
  plugins: [],
}
